import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import javax.swing.JOptionPane;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Viktorija.Balalajeva
 */


public class PD1_PA_Balalajeva_GUI extends javax.swing.JFrame {
    public static int currentUserId = -1;
    private int selectedTest = 0;
    
    public PD1_PA_Balalajeva_GUI() {
        initComponents();
        this.setLocationRelativeTo(null);
        
    } 

    private boolean loginUser(String text, String text0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public static Connection getConnection() {
        Connection conn = null;

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            conn = DriverManager.getConnection(
                "jdbc:derby://localhost:1527/QuizDB",
                "app",
                "app"
            );

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        return conn;
    }
    
     public class DBConnection {
         private static final String URL = "jdbc:derby://localhost:1527/QuizDB";
         private static final String USER = "dbuser";
         private static final String PASSWORD = "dbuser";
         
         public static Connection getConnection() {
             try {
                 return DriverManager.getConnection(URL, USER, PASSWORD);
             } catch (SQLException e){
                 e.printStackTrace();
                 return null;
             }
         }
     }
     
         private void registerUser() {
             String name = vardsText1.getText();
             String surname = uzvardsText1.getText();
             String username = lietvardsText2.getText();
             String password = paroleText1.getText();
             String confirm = paroleAtkText1.getText();

             if(!password.equals(confirm)) {
                 javax.swing.JOptionPane.showMessageDialog(this, "Paroles nesakrīt!");
                 return;
         }
         
             String sql = "INSERT INTO USERS (VARDS, UZVARDS, LIETOTAJVARDS, PAROLE) VALUES (?,?,?,?)";
             try (Connection conn = DBConnection.getConnection();
                     java.sql.PreparedStatement pst = conn.prepareStatement(sql)){
                 pst.setString(1, name);
                 pst.setString(2, surname);
                 pst.setString(3, username);
                 pst.setString(4, password);
                 pst.executeUpdate();
                 javax.swing.JOptionPane.showMessageDialog(this, "Reģistrācija veiksmīga!");
             }catch (Exception e) {
                 e.printStackTrace();
             }
     }

        private void loginUser(){
            String username = lietvardsText4.getText();
            String password = paroleText4.getText();
            
            String sql = "SELECT ID FROM USERS WHERE LIETOTAJVARDS = ? AND PAROLE = ?";
            try(Connection conn = DBConnection.getConnection();
                     java.sql.PreparedStatement pst = conn.prepareStatement(sql)){
                 pst.setString(1, username);
                 pst.setString(2, password);
                 java.sql.ResultSet rs = pst.executeQuery();
                 if(rs.next()){
                     currentUserId = rs.getInt("ID");
                 javax.swing.JOptionPane.showMessageDialog(this, "Veiksmīga pieslēgšanās!");
                 }else{
                 javax.swing.JOptionPane.showMessageDialog(this, "Nepareizs lietotājvārds vai parole!");
                 }
             }catch (Exception e) {
                 e.printStackTrace();
             }
        }
        
        public class testLogic{
            private int currentQuestion = 0;
            private int correctAnswers = 0;
            private int[] correctAnswerIndex;
            
            public testLogic(int[]correctAnswerIndex){
                this.correctAnswerIndex = correctAnswerIndex;
            }
            
            public void checkAnswer(int selectedIndex){
                if(selectedIndex == correctAnswerIndex[currentQuestion]){
                    correctAnswers++;
                }
            }
            
            public void nextQuestion(){
                currentQuestion++;
            }
            
            public boolean hasNextQueston(){
                
            }
        }
        
        private void saveResult(int percent, java.sql.Date date, String atbildes){
            String sql = "INSERT INTO RESULTS(USER_ID, REZULTATS, TEST_DATE, PAREIZAS_ATBILDES) VALUES (?,?,?,?)";
            try(Connection conn = DBConnection.getConnection();
                     java.sql.PreparedStatement pst = conn.prepareStatement(sql)){
                    pst.setInt(1, currentUserId);
                    pst.setInt(2, percent);
                    pst.setDate(3, date);
                    pst.setString(4, atbildes);
                    pst.executeUpdate();
            }catch(Exception e) {
                e.printStackTrace();
            }
        }
        
        public class TestLogic {
           
        private int currentQuestion = 0;
        private int correctAnswers = 0;

        private int[] correctAnswerIndex;

        
        public TestLogic(int[] correctAnswerIndex) {
        this.correctAnswerIndex = correctAnswerIndex;
        }

        // Atbildes pārbaude
        public void checkAnswer(int selectedIndex) {

            if (selectedIndex == correctAnswerIndex[currentQuestion]) {
            correctAnswers++;
            }
        }

        public void nextQuestion() {
        if (currentQuestion < correctAnswerIndex.length - 1) {
            currentQuestion++;
            }
        }

        // Vai ir vēl kādi jautājumi
        public boolean hasNextQuestion() {
        return currentQuestion < correctAnswerIndex.length - 1;
        }
        
        // Pareizo atbilžu skaits
        public int getCorrectAnswers() {
        return correctAnswers;
        }

        public int getTotalQuestions() {
            return correctAnswerIndex.length;
        }

        // Kopējais jautājumu skaits
        public int getPercentage() {

            if (correctAnswerIndex.length == 0) {
                return 0;
            }

            return (int)(((double) correctAnswers / correctAnswerIndex.length) * 100);
        }

        public void resetTest() {
            currentQuestion = 0;
            correctAnswers = 0;
        }
    }
        
        private final TestLogic testLogic1 = new TestLogic(
        new int[]{2, 1, 2, 0, 1}
        );
        
        private final TestLogic testLogic2 = new TestLogic(
        new int[]{2, 1, 2, 0, 1}
        );
        
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        registresanaJd = new javax.swing.JDialog();
        paroleText1 = new javax.swing.JTextField();
        paroleAtkText1 = new javax.swing.JTextField();
        regLab1 = new javax.swing.JLabel();
        regBut3 = new javax.swing.JButton();
        vardsLab1 = new javax.swing.JLabel();
        uzvardsLab1 = new javax.swing.JLabel();
        letvardsLab2 = new javax.swing.JLabel();
        paroleLab2 = new javax.swing.JLabel();
        paroleAtkLab1 = new javax.swing.JLabel();
        vardsText1 = new javax.swing.JTextField();
        uzvardsText1 = new javax.swing.JTextField();
        lietvardsText2 = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        izietMenu = new javax.swing.JMenu();
        ielogosanaJd = new javax.swing.JDialog();
        ielogLab4 = new javax.swing.JLabel();
        letvardsLab4 = new javax.swing.JLabel();
        paroleLab4 = new javax.swing.JLabel();
        lietvardsText4 = new javax.swing.JTextField();
        paroleText4 = new javax.swing.JTextField();
        regBut14 = new javax.swing.JButton();
        ilogBut = new javax.swing.JButton();
        jMenuBar2 = new javax.swing.JMenuBar();
        atpMenu6 = new javax.swing.JMenu();
        rezultatiJd = new javax.swing.JDialog();
        testLab2 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        testVisumsLab5 = new javax.swing.JLabel();
        testVisumsLab6 = new javax.swing.JLabel();
        testVisumsLab7 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextPane3 = new javax.swing.JTextPane();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextPane4 = new javax.swing.JTextPane();
        atpakal2 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        testVisumsLab8 = new javax.swing.JLabel();
        testVisumsLab9 = new javax.swing.JLabel();
        testVisumsLab10 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTextPane5 = new javax.swing.JTextPane();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextPane6 = new javax.swing.JTextPane();
        tests1 = new javax.swing.JDialog();
        testLab = new javax.swing.JLabel();
        testVisumsLab = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        saktTestuBut = new javax.swing.JButton();
        izejaBut = new javax.swing.JButton();
        jMenuBar4 = new javax.swing.JMenuBar();
        izejaMenu = new javax.swing.JMenu();
        test1jautajums1 = new javax.swing.JDialog();
        testSkaitlisLab = new javax.swing.JLabel();
        jautajumsLab1 = new javax.swing.JLabel();
        tālākBut = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        atbilde1 = new javax.swing.JCheckBox();
        atbilde2 = new javax.swing.JCheckBox();
        pAtbilde = new javax.swing.JCheckBox();
        jMenuBar5 = new javax.swing.JMenuBar();
        izietMenu1 = new javax.swing.JMenu();
        test1jautajums2 = new javax.swing.JDialog();
        testSkaitlisLab1 = new javax.swing.JLabel();
        jautajumsLab2 = new javax.swing.JLabel();
        tālākBut1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        atbilde3 = new javax.swing.JCheckBox();
        Patbilde1 = new javax.swing.JCheckBox();
        atbilde4 = new javax.swing.JCheckBox();
        jMenuBar6 = new javax.swing.JMenuBar();
        atpMenu2 = new javax.swing.JMenu();
        test1jautajums3 = new javax.swing.JDialog();
        testSkaitlisLab2 = new javax.swing.JLabel();
        jautajumsLab3 = new javax.swing.JLabel();
        tālākBut2 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        atbilde5 = new javax.swing.JCheckBox();
        atbilde6 = new javax.swing.JCheckBox();
        pAtbilde2 = new javax.swing.JCheckBox();
        jMenuBar7 = new javax.swing.JMenuBar();
        atpMenu3 = new javax.swing.JMenu();
        test1jautajums4 = new javax.swing.JDialog();
        testSkaitlisLab3 = new javax.swing.JLabel();
        jautajumsLab4 = new javax.swing.JLabel();
        tālākBut3 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        pAtbilde4 = new javax.swing.JCheckBox();
        atbilde7 = new javax.swing.JCheckBox();
        atbilde8 = new javax.swing.JCheckBox();
        jMenuBar8 = new javax.swing.JMenuBar();
        atpMenu4 = new javax.swing.JMenu();
        test1jautajums5 = new javax.swing.JDialog();
        testSkaitlisLab4 = new javax.swing.JLabel();
        jautajumsLab5 = new javax.swing.JLabel();
        beigtBut = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        atbilde9 = new javax.swing.JCheckBox();
        pAtbilde5 = new javax.swing.JCheckBox();
        atbilde10 = new javax.swing.JCheckBox();
        jMenuBar9 = new javax.swing.JMenuBar();
        izietMenu5 = new javax.swing.JMenu();
        test1Rezultāti = new javax.swing.JDialog();
        testLab1 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        testVisumsLab2 = new javax.swing.JLabel();
        rezultLab3 = new javax.swing.JLabel();
        pAtbildesLab4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        testVisumsLab14 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTextPane9 = new javax.swing.JTextPane();
        jScrollPane11 = new javax.swing.JScrollPane();
        jTextPane11 = new javax.swing.JTextPane();
        atpakalBut1 = new javax.swing.JButton();
        tests2 = new javax.swing.JDialog();
        testLab3 = new javax.swing.JLabel();
        testVisumsLab1 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        saktTestuBut1 = new javax.swing.JButton();
        izejaBut3 = new javax.swing.JButton();
        jMenuBar11 = new javax.swing.JMenuBar();
        izejaMenu1 = new javax.swing.JMenu();
        test2jautajums1 = new javax.swing.JDialog();
        testSkaitlisLab5 = new javax.swing.JLabel();
        jautajumsLab6 = new javax.swing.JLabel();
        tālākBut4 = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        atbilde11 = new javax.swing.JCheckBox();
        atbilde12 = new javax.swing.JCheckBox();
        pAtbilde1 = new javax.swing.JCheckBox();
        jMenuBar12 = new javax.swing.JMenuBar();
        izietMenu8 = new javax.swing.JMenu();
        test2jautajums2 = new javax.swing.JDialog();
        testSkaitlisLab6 = new javax.swing.JLabel();
        jautajumsLab7 = new javax.swing.JLabel();
        tālākBut5 = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        atbilde13 = new javax.swing.JCheckBox();
        Patbilde2 = new javax.swing.JCheckBox();
        atbilde14 = new javax.swing.JCheckBox();
        jMenuBar13 = new javax.swing.JMenuBar();
        atpMenu9 = new javax.swing.JMenu();
        test2jautajums3 = new javax.swing.JDialog();
        testSkaitlisLab7 = new javax.swing.JLabel();
        jautajumsLab8 = new javax.swing.JLabel();
        tālākBut6 = new javax.swing.JButton();
        jPanel14 = new javax.swing.JPanel();
        atbilde15 = new javax.swing.JCheckBox();
        atbilde16 = new javax.swing.JCheckBox();
        pAtbilde3 = new javax.swing.JCheckBox();
        jMenuBar14 = new javax.swing.JMenuBar();
        atpMenu10 = new javax.swing.JMenu();
        test2jautajums4 = new javax.swing.JDialog();
        testSkaitlisLab8 = new javax.swing.JLabel();
        jautajumsLab9 = new javax.swing.JLabel();
        tālākBut7 = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        pAtbilde6 = new javax.swing.JCheckBox();
        atbilde17 = new javax.swing.JCheckBox();
        atbilde18 = new javax.swing.JCheckBox();
        jMenuBar15 = new javax.swing.JMenuBar();
        atpMenu11 = new javax.swing.JMenu();
        test2jautajums5 = new javax.swing.JDialog();
        testSkaitlisLab9 = new javax.swing.JLabel();
        jautajumsLab10 = new javax.swing.JLabel();
        beigtBut1 = new javax.swing.JButton();
        jPanel16 = new javax.swing.JPanel();
        atbilde19 = new javax.swing.JCheckBox();
        pAtbilde7 = new javax.swing.JCheckBox();
        atbilde20 = new javax.swing.JCheckBox();
        jMenuBar16 = new javax.swing.JMenuBar();
        izietMenu12 = new javax.swing.JMenu();
        test2Rezultāti = new javax.swing.JDialog();
        testLab4 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        testVisumsLab11 = new javax.swing.JLabel();
        testVisumsLab12 = new javax.swing.JLabel();
        testVisumsLab13 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTextPane7 = new javax.swing.JTextPane();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTextPane8 = new javax.swing.JTextPane();
        pAtbildesLab5 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        jTextPane10 = new javax.swing.JTextPane();
        izejaBut4 = new javax.swing.JButton();
        ielogLab3 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        test1But1 = new javax.swing.JButton();
        test2But = new javax.swing.JButton();
        izejaBut5 = new javax.swing.JButton();
        rezBut2 = new javax.swing.JButton();

        registresanaJd.setTitle("Reģistrācijas veidlapa");

        regLab1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        regLab1.setForeground(new java.awt.Color(0, 102, 153));
        regLab1.setText("Reģistrācijas veidlapa");

        regBut3.setBackground(new java.awt.Color(153, 204, 255));
        regBut3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        regBut3.setForeground(new java.awt.Color(0, 102, 153));
        regBut3.setText("Reģistrēties");
        regBut3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regBut3ActionPerformed(evt);
            }
        });

        vardsLab1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        vardsLab1.setForeground(new java.awt.Color(0, 102, 153));
        vardsLab1.setText("Vārds:");

        uzvardsLab1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        uzvardsLab1.setForeground(new java.awt.Color(0, 102, 153));
        uzvardsLab1.setText("Uzvārds:");

        letvardsLab2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        letvardsLab2.setForeground(new java.awt.Color(0, 102, 153));
        letvardsLab2.setText("Lietotājvārds:");

        paroleLab2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        paroleLab2.setForeground(new java.awt.Color(0, 102, 153));
        paroleLab2.setText("Parole:");

        paroleAtkLab1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        paroleAtkLab1.setForeground(new java.awt.Color(0, 102, 153));
        paroleAtkLab1.setText("Parole(atkārtoti):");

        vardsText1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vardsText1ActionPerformed(evt);
            }
        });

        izietMenu.setText("Iziet");
        izietMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                izietMenuMouseClicked(evt);
            }
        });
        jMenuBar1.add(izietMenu);

        registresanaJd.setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout registresanaJdLayout = new javax.swing.GroupLayout(registresanaJd.getContentPane());
        registresanaJd.getContentPane().setLayout(registresanaJdLayout);
        registresanaJdLayout.setHorizontalGroup(
            registresanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(registresanaJdLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(registresanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(uzvardsLab1)
                    .addComponent(letvardsLab2)
                    .addComponent(paroleLab2)
                    .addComponent(paroleAtkLab1)
                    .addComponent(vardsLab1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(registresanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(paroleText1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
                    .addComponent(lietvardsText2, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(uzvardsText1, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(vardsText1, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(paroleAtkText1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, registresanaJdLayout.createSequentialGroup()
                .addContainerGap(120, Short.MAX_VALUE)
                .addGroup(registresanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, registresanaJdLayout.createSequentialGroup()
                        .addComponent(regLab1)
                        .addGap(101, 101, 101))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, registresanaJdLayout.createSequentialGroup()
                        .addComponent(regBut3)
                        .addGap(144, 144, 144))))
        );
        registresanaJdLayout.setVerticalGroup(
            registresanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(registresanaJdLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(regLab1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(registresanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(vardsLab1)
                    .addComponent(vardsText1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(registresanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(uzvardsLab1)
                    .addComponent(uzvardsText1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(registresanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(letvardsLab2)
                    .addComponent(lietvardsText2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(registresanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(paroleLab2)
                    .addComponent(paroleText1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(registresanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(paroleAtkLab1)
                    .addComponent(paroleAtkText1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(regBut3)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        ielogosanaJd.setTitle("Ielogošanās_forma");

        ielogLab4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        ielogLab4.setForeground(new java.awt.Color(0, 102, 153));
        ielogLab4.setText("Ielogošanās forma");

        letvardsLab4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        letvardsLab4.setForeground(new java.awt.Color(0, 102, 153));
        letvardsLab4.setText("Lietotājvārds:");

        paroleLab4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        paroleLab4.setForeground(new java.awt.Color(0, 102, 153));
        paroleLab4.setText("Parole:");

        regBut14.setBackground(new java.awt.Color(153, 204, 255));
        regBut14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        regBut14.setForeground(new java.awt.Color(0, 102, 153));
        regBut14.setText("Reģistrēties");
        regBut14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regBut14ActionPerformed(evt);
            }
        });

        ilogBut.setBackground(new java.awt.Color(153, 204, 255));
        ilogBut.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ilogBut.setForeground(new java.awt.Color(0, 102, 153));
        ilogBut.setText("Ielogoties");
        ilogBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ilogButActionPerformed(evt);
            }
        });

        atpMenu6.setText("Atpakaļ");
        atpMenu6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                atpMenu6MouseClicked(evt);
            }
        });
        jMenuBar2.add(atpMenu6);

        ielogosanaJd.setJMenuBar(jMenuBar2);

        javax.swing.GroupLayout ielogosanaJdLayout = new javax.swing.GroupLayout(ielogosanaJd.getContentPane());
        ielogosanaJd.getContentPane().setLayout(ielogosanaJdLayout);
        ielogosanaJdLayout.setHorizontalGroup(
            ielogosanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ielogosanaJdLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(ielogosanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ielogosanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ielogosanaJdLayout.createSequentialGroup()
                            .addGroup(ielogosanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(paroleLab4)
                                .addComponent(letvardsLab4))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(ielogosanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(lietvardsText4, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(paroleText4, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(ielogosanaJdLayout.createSequentialGroup()
                            .addGap(49, 49, 49)
                            .addComponent(ilogBut, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(regBut14)))
                    .addGroup(ielogosanaJdLayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(ielogLab4)))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        ielogosanaJdLayout.setVerticalGroup(
            ielogosanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ielogosanaJdLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(ielogLab4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(ielogosanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(letvardsLab4)
                    .addComponent(lietvardsText4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ielogosanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(paroleLab4)
                    .addComponent(paroleText4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(ielogosanaJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(regBut14)
                    .addComponent(ilogBut))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        rezultatiJd.setTitle("Rezultāti par testiem");

        testLab2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        testLab2.setForeground(new java.awt.Color(0, 102, 153));
        testLab2.setText("Rezultāti");

        jPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        testVisumsLab5.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testVisumsLab5.setForeground(new java.awt.Color(0, 102, 153));
        testVisumsLab5.setText("Tests \"Pārbaudi savas zināšanas par Visumu\"");

        testVisumsLab6.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testVisumsLab6.setForeground(new java.awt.Color(0, 102, 153));
        testVisumsLab6.setText("Rezultāts: ");

        testVisumsLab7.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testVisumsLab7.setForeground(new java.awt.Color(0, 102, 153));
        testVisumsLab7.setText("Datums:");

        jScrollPane3.setViewportView(jTextPane3);

        jScrollPane4.setViewportView(jTextPane4);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(testVisumsLab5)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(testVisumsLab6)
                            .addComponent(testVisumsLab7))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                            .addComponent(jScrollPane3))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testVisumsLab5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(testVisumsLab6, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(testVisumsLab7)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
        );

        atpakal2.setBackground(new java.awt.Color(153, 204, 255));
        atpakal2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atpakal2.setForeground(new java.awt.Color(0, 102, 153));
        atpakal2.setText("Atpakaļ");
        atpakal2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atpakal2ActionPerformed(evt);
            }
        });

        jPanel9.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        testVisumsLab8.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testVisumsLab8.setForeground(new java.awt.Color(0, 102, 153));
        testVisumsLab8.setText("Tests \"Tehnoloģijas un internets\"");

        testVisumsLab9.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testVisumsLab9.setForeground(new java.awt.Color(0, 102, 153));
        testVisumsLab9.setText("Rezultāts: ");

        testVisumsLab10.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testVisumsLab10.setForeground(new java.awt.Color(0, 102, 153));
        testVisumsLab10.setText("Datums:");

        jScrollPane5.setViewportView(jTextPane5);

        jScrollPane6.setViewportView(jTextPane6);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(testVisumsLab8)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(testVisumsLab9)
                            .addComponent(testVisumsLab10))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testVisumsLab8, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(testVisumsLab9, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(testVisumsLab10)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout rezultatiJdLayout = new javax.swing.GroupLayout(rezultatiJd.getContentPane());
        rezultatiJd.getContentPane().setLayout(rezultatiJdLayout);
        rezultatiJdLayout.setHorizontalGroup(
            rezultatiJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rezultatiJdLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(rezultatiJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, rezultatiJdLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(atpakal2))
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(rezultatiJdLayout.createSequentialGroup()
                .addGap(148, 148, 148)
                .addComponent(testLab2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        rezultatiJdLayout.setVerticalGroup(
            rezultatiJdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rezultatiJdLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testLab2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(atpakal2)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        tests1.setTitle("Tests par Visumu");
        tests1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tests1MouseClicked(evt);
            }
        });

        testLab.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        testLab.setForeground(new java.awt.Color(0, 102, 153));
        testLab.setText("Tests 1 ");

        testVisumsLab.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testVisumsLab.setForeground(new java.awt.Color(0, 102, 153));
        testVisumsLab.setText("\"Pārbaudi savas zināšanas par Visumu\"");

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        saktTestuBut.setBackground(new java.awt.Color(153, 204, 255));
        saktTestuBut.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        saktTestuBut.setForeground(new java.awt.Color(0, 102, 153));
        saktTestuBut.setText("Sākt Testu");
        saktTestuBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saktTestuButActionPerformed(evt);
            }
        });

        izejaBut.setBackground(new java.awt.Color(153, 204, 255));
        izejaBut.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        izejaBut.setForeground(new java.awt.Color(0, 102, 153));
        izejaBut.setText("Iziet");
        izejaBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                izejaButActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(saktTestuBut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(izejaBut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(15, 15, 15))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(saktTestuBut)
                .addGap(18, 18, 18)
                .addComponent(izejaBut)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        izejaMenu.setText("Iziet");
        izejaMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                izejaMenuMouseClicked(evt);
            }
        });
        jMenuBar4.add(izejaMenu);

        tests1.setJMenuBar(jMenuBar4);

        javax.swing.GroupLayout tests1Layout = new javax.swing.GroupLayout(tests1.getContentPane());
        tests1.getContentPane().setLayout(tests1Layout);
        tests1Layout.setHorizontalGroup(
            tests1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tests1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(testLab)
                .addGap(139, 139, 139))
            .addGroup(tests1Layout.createSequentialGroup()
                .addGroup(tests1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tests1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(testVisumsLab))
                    .addGroup(tests1Layout.createSequentialGroup()
                        .addGap(102, 102, 102)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        tests1Layout.setVerticalGroup(
            tests1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tests1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testLab)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(testVisumsLab)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        test1jautajums1.setTitle("1 Jautājums");

        testSkaitlisLab.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testSkaitlisLab.setForeground(new java.awt.Color(0, 102, 153));
        testSkaitlisLab.setText("1 no 5");

        jautajumsLab1.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jautajumsLab1.setForeground(new java.awt.Color(0, 102, 153));
        jautajumsLab1.setText("Kura ir lielākā planēta Saules sistēmā?");

        tālākBut.setBackground(new java.awt.Color(153, 204, 255));
        tālākBut.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tālākBut.setForeground(new java.awt.Color(0, 102, 153));
        tālākBut.setText("Tālāk");
        tālākBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tālākButActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        atbilde1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde1.setForeground(new java.awt.Color(0, 102, 153));
        atbilde1.setText("Zeme");

        atbilde2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde2.setForeground(new java.awt.Color(0, 102, 153));
        atbilde2.setText("Marss");

        pAtbilde.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        pAtbilde.setForeground(new java.awt.Color(0, 102, 153));
        pAtbilde.setText("Jupiters");
        pAtbilde.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pAtbildeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(atbilde1)
                    .addComponent(atbilde2)
                    .addComponent(pAtbilde))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(atbilde1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(atbilde2)
                .addGap(12, 12, 12)
                .addComponent(pAtbilde)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        izietMenu1.setText("Iziet");
        izietMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                izietMenu1MouseClicked(evt);
            }
        });
        jMenuBar5.add(izietMenu1);

        test1jautajums1.setJMenuBar(jMenuBar5);

        javax.swing.GroupLayout test1jautajums1Layout = new javax.swing.GroupLayout(test1jautajums1.getContentPane());
        test1jautajums1.getContentPane().setLayout(test1jautajums1Layout);
        test1jautajums1Layout.setHorizontalGroup(
            test1jautajums1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, test1jautajums1Layout.createSequentialGroup()
                .addGroup(test1jautajums1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(test1jautajums1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(testSkaitlisLab))
                    .addGroup(test1jautajums1Layout.createSequentialGroup()
                        .addContainerGap(312, Short.MAX_VALUE)
                        .addComponent(tālākBut))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, test1jautajums1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(test1jautajums1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(test1jautajums1Layout.createSequentialGroup()
                                .addComponent(jautajumsLab1)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(16, 16, 16))
        );
        test1jautajums1Layout.setVerticalGroup(
            test1jautajums1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(test1jautajums1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testSkaitlisLab)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jautajumsLab1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tālākBut)
                .addGap(19, 19, 19))
        );

        test1jautajums2.setTitle("2 Jautājums");

        testSkaitlisLab1.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testSkaitlisLab1.setForeground(new java.awt.Color(0, 102, 153));
        testSkaitlisLab1.setText("2 no 5");

        jautajumsLab2.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jautajumsLab2.setForeground(new java.awt.Color(0, 102, 153));
        jautajumsLab2.setText("Kā sauc Zemes dibisko pavadoņu?");

        tālākBut1.setBackground(new java.awt.Color(153, 204, 255));
        tālākBut1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tālākBut1.setForeground(new java.awt.Color(0, 102, 153));
        tālākBut1.setText("Tālāk");
        tālākBut1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tālākBut1ActionPerformed(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        atbilde3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde3.setForeground(new java.awt.Color(0, 102, 153));
        atbilde3.setText("Fobs");

        Patbilde1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Patbilde1.setForeground(new java.awt.Color(0, 102, 153));
        Patbilde1.setText("Mēness");

        atbilde4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde4.setForeground(new java.awt.Color(0, 102, 153));
        atbilde4.setText("Titāns");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(atbilde3)
                    .addComponent(Patbilde1)
                    .addComponent(atbilde4))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(atbilde3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Patbilde1)
                .addGap(12, 12, 12)
                .addComponent(atbilde4)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        atpMenu2.setText("Atpakaļ");
        atpMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                atpMenu2MouseClicked(evt);
            }
        });
        jMenuBar6.add(atpMenu2);

        test1jautajums2.setJMenuBar(jMenuBar6);

        javax.swing.GroupLayout test1jautajums2Layout = new javax.swing.GroupLayout(test1jautajums2.getContentPane());
        test1jautajums2.getContentPane().setLayout(test1jautajums2Layout);
        test1jautajums2Layout.setHorizontalGroup(
            test1jautajums2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, test1jautajums2Layout.createSequentialGroup()
                .addGroup(test1jautajums2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(test1jautajums2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(testSkaitlisLab1))
                    .addGroup(test1jautajums2Layout.createSequentialGroup()
                        .addContainerGap(312, Short.MAX_VALUE)
                        .addComponent(tālākBut1))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, test1jautajums2Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(test1jautajums2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(test1jautajums2Layout.createSequentialGroup()
                                .addComponent(jautajumsLab2)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(16, 16, 16))
        );
        test1jautajums2Layout.setVerticalGroup(
            test1jautajums2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(test1jautajums2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testSkaitlisLab1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jautajumsLab2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tālākBut1)
                .addGap(19, 19, 19))
        );

        test1jautajums3.setTitle("3 Jautājums");

        testSkaitlisLab2.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testSkaitlisLab2.setForeground(new java.awt.Color(0, 102, 153));
        testSkaitlisLab2.setText("3 no 5");

        jautajumsLab3.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jautajumsLab3.setForeground(new java.awt.Color(0, 102, 153));
        jautajumsLab3.setText("Kas ir Saules sistēmas centrs?");

        tālākBut2.setBackground(new java.awt.Color(153, 204, 255));
        tālākBut2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tālākBut2.setForeground(new java.awt.Color(0, 102, 153));
        tālākBut2.setText("Tālāk");
        tālākBut2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tālākBut2ActionPerformed(evt);
            }
        });

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        atbilde5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde5.setForeground(new java.awt.Color(0, 102, 153));
        atbilde5.setText("Zeme");

        atbilde6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde6.setForeground(new java.awt.Color(0, 102, 153));
        atbilde6.setText("Mēness");

        pAtbilde2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        pAtbilde2.setForeground(new java.awt.Color(0, 102, 153));
        pAtbilde2.setText("Saule");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(atbilde5)
                    .addComponent(atbilde6)
                    .addComponent(pAtbilde2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(atbilde5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(atbilde6)
                .addGap(12, 12, 12)
                .addComponent(pAtbilde2)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        atpMenu3.setText("Atpakaļ");
        atpMenu3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                atpMenu3MouseClicked(evt);
            }
        });
        jMenuBar7.add(atpMenu3);

        test1jautajums3.setJMenuBar(jMenuBar7);

        javax.swing.GroupLayout test1jautajums3Layout = new javax.swing.GroupLayout(test1jautajums3.getContentPane());
        test1jautajums3.getContentPane().setLayout(test1jautajums3Layout);
        test1jautajums3Layout.setHorizontalGroup(
            test1jautajums3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, test1jautajums3Layout.createSequentialGroup()
                .addGroup(test1jautajums3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(test1jautajums3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(testSkaitlisLab2))
                    .addGroup(test1jautajums3Layout.createSequentialGroup()
                        .addContainerGap(312, Short.MAX_VALUE)
                        .addComponent(tālākBut2))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, test1jautajums3Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(test1jautajums3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(test1jautajums3Layout.createSequentialGroup()
                                .addComponent(jautajumsLab3)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(16, 16, 16))
        );
        test1jautajums3Layout.setVerticalGroup(
            test1jautajums3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(test1jautajums3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testSkaitlisLab2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jautajumsLab3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tālākBut2)
                .addGap(19, 19, 19))
        );

        test1jautajums4.setTitle("4  Jautājums");

        testSkaitlisLab3.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testSkaitlisLab3.setForeground(new java.awt.Color(0, 102, 153));
        testSkaitlisLab3.setText("4 no 5");

        jautajumsLab4.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jautajumsLab4.setForeground(new java.awt.Color(0, 102, 153));
        jautajumsLab4.setText("Kā sauc galaktiku, kurā atrodas Zeme?");

        tālākBut3.setBackground(new java.awt.Color(153, 204, 255));
        tālākBut3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tālākBut3.setForeground(new java.awt.Color(0, 102, 153));
        tālākBut3.setText("Tālāk");
        tālākBut3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tālākBut3ActionPerformed(evt);
            }
        });

        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        pAtbilde4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        pAtbilde4.setForeground(new java.awt.Color(0, 102, 153));
        pAtbilde4.setText("Piena Ceļš");

        atbilde7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde7.setForeground(new java.awt.Color(0, 102, 153));
        atbilde7.setText("Oriona Miglājs");

        atbilde8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde8.setForeground(new java.awt.Color(0, 102, 153));
        atbilde8.setText("Andromeda");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pAtbilde4)
                    .addComponent(atbilde7)
                    .addComponent(atbilde8))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pAtbilde4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(atbilde7)
                .addGap(12, 12, 12)
                .addComponent(atbilde8)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        atpMenu4.setText("Atpakaļ");
        atpMenu4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                atpMenu4MouseClicked(evt);
            }
        });
        jMenuBar8.add(atpMenu4);

        test1jautajums4.setJMenuBar(jMenuBar8);

        javax.swing.GroupLayout test1jautajums4Layout = new javax.swing.GroupLayout(test1jautajums4.getContentPane());
        test1jautajums4.getContentPane().setLayout(test1jautajums4Layout);
        test1jautajums4Layout.setHorizontalGroup(
            test1jautajums4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, test1jautajums4Layout.createSequentialGroup()
                .addGroup(test1jautajums4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(test1jautajums4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(testSkaitlisLab3))
                    .addGroup(test1jautajums4Layout.createSequentialGroup()
                        .addContainerGap(312, Short.MAX_VALUE)
                        .addComponent(tālākBut3))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, test1jautajums4Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(test1jautajums4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(test1jautajums4Layout.createSequentialGroup()
                                .addComponent(jautajumsLab4)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(16, 16, 16))
        );
        test1jautajums4Layout.setVerticalGroup(
            test1jautajums4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(test1jautajums4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testSkaitlisLab3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jautajumsLab4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tālākBut3)
                .addGap(19, 19, 19))
        );

        test1jautajums5.setTitle("5 Jautājums");

        testSkaitlisLab4.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testSkaitlisLab4.setForeground(new java.awt.Color(0, 102, 153));
        testSkaitlisLab4.setText("5 no 5");

        jautajumsLab5.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jautajumsLab5.setForeground(new java.awt.Color(0, 102, 153));
        jautajumsLab5.setText("Kā sauc pirmo cilvēku, kurš devās kosmosā?");

        beigtBut.setBackground(new java.awt.Color(153, 204, 255));
        beigtBut.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        beigtBut.setForeground(new java.awt.Color(0, 102, 153));
        beigtBut.setText("Beigt");
        beigtBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beigtButActionPerformed(evt);
            }
        });

        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        atbilde9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde9.setForeground(new java.awt.Color(0, 102, 153));
        atbilde9.setText("Nīls Ārmstrongs");

        pAtbilde5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        pAtbilde5.setForeground(new java.awt.Color(0, 102, 153));
        pAtbilde5.setText("Jurijs Gagarins");

        atbilde10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde10.setForeground(new java.awt.Color(0, 102, 153));
        atbilde10.setText("Aleksejs Leonovs");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(atbilde9)
                    .addComponent(pAtbilde5)
                    .addComponent(atbilde10))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(atbilde9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pAtbilde5)
                .addGap(12, 12, 12)
                .addComponent(atbilde10)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        izietMenu5.setText("Iziet");
        izietMenu5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                izietMenu5MouseClicked(evt);
            }
        });
        jMenuBar9.add(izietMenu5);

        test1jautajums5.setJMenuBar(jMenuBar9);

        javax.swing.GroupLayout test1jautajums5Layout = new javax.swing.GroupLayout(test1jautajums5.getContentPane());
        test1jautajums5.getContentPane().setLayout(test1jautajums5Layout);
        test1jautajums5Layout.setHorizontalGroup(
            test1jautajums5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, test1jautajums5Layout.createSequentialGroup()
                .addGroup(test1jautajums5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(test1jautajums5Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(testSkaitlisLab4))
                    .addGroup(test1jautajums5Layout.createSequentialGroup()
                        .addContainerGap(312, Short.MAX_VALUE)
                        .addComponent(beigtBut))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, test1jautajums5Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(test1jautajums5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(test1jautajums5Layout.createSequentialGroup()
                                .addComponent(jautajumsLab5)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(16, 16, 16))
        );
        test1jautajums5Layout.setVerticalGroup(
            test1jautajums5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(test1jautajums5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testSkaitlisLab4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jautajumsLab5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(beigtBut)
                .addGap(19, 19, 19))
        );

        test1Rezultāti.setTitle("Rezultāti par Tests 1");

        testLab1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        testLab1.setForeground(new java.awt.Color(0, 102, 153));
        testLab1.setText("Rezultāti");

        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        testVisumsLab2.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testVisumsLab2.setForeground(new java.awt.Color(0, 102, 153));
        testVisumsLab2.setText("Tests \"Pārbaudi savas zināšanas par Visumu\"");

        rezultLab3.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        rezultLab3.setForeground(new java.awt.Color(0, 102, 153));
        rezultLab3.setText("Rezultāts: ");

        pAtbildesLab4.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        pAtbildesLab4.setForeground(new java.awt.Color(0, 102, 153));
        pAtbildesLab4.setText("Pareizas atbildes:");

        jScrollPane1.setViewportView(jTextPane1);

        testVisumsLab14.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testVisumsLab14.setForeground(new java.awt.Color(0, 102, 153));
        testVisumsLab14.setText("Datums:");

        jScrollPane9.setViewportView(jTextPane9);

        jScrollPane11.setViewportView(jTextPane11);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(testVisumsLab2))
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addComponent(rezultLab3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addComponent(pAtbildesLab4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jScrollPane11))
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addComponent(testVisumsLab14)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jScrollPane9))))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testVisumsLab2)
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rezultLab3)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pAtbildesLab4)
                    .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(testVisumsLab14)
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        atpakalBut1.setBackground(new java.awt.Color(153, 204, 255));
        atpakalBut1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atpakalBut1.setForeground(new java.awt.Color(0, 102, 153));
        atpakalBut1.setText("Atpakaļ");
        atpakalBut1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atpakalBut1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout test1RezultātiLayout = new javax.swing.GroupLayout(test1Rezultāti.getContentPane());
        test1Rezultāti.getContentPane().setLayout(test1RezultātiLayout);
        test1RezultātiLayout.setHorizontalGroup(
            test1RezultātiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, test1RezultātiLayout.createSequentialGroup()
                .addGroup(test1RezultātiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(test1RezultātiLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(atpakalBut1))
                    .addGroup(test1RezultātiLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(test1RezultātiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(testLab1)
                            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(20, 20, 20))
        );
        test1RezultātiLayout.setVerticalGroup(
            test1RezultātiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(test1RezultātiLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(testLab1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(atpakalBut1)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        tests2.setTitle("Tests par tehnoloģijas un internets");

        testLab3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        testLab3.setForeground(new java.awt.Color(0, 102, 153));
        testLab3.setText("Tests 2 ");

        testVisumsLab1.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testVisumsLab1.setForeground(new java.awt.Color(0, 102, 153));
        testVisumsLab1.setText("\"Tehnoloģijas un internets\"");

        jPanel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        saktTestuBut1.setBackground(new java.awt.Color(153, 204, 255));
        saktTestuBut1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        saktTestuBut1.setForeground(new java.awt.Color(0, 102, 153));
        saktTestuBut1.setText("Sākt Testu");
        saktTestuBut1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saktTestuBut1ActionPerformed(evt);
            }
        });

        izejaBut3.setBackground(new java.awt.Color(153, 204, 255));
        izejaBut3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        izejaBut3.setForeground(new java.awt.Color(0, 102, 153));
        izejaBut3.setText("Iziet");
        izejaBut3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                izejaBut3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(saktTestuBut1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(izejaBut3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(15, 15, 15))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(saktTestuBut1)
                .addGap(18, 18, 18)
                .addComponent(izejaBut3)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        izejaMenu1.setText("Iziet");
        izejaMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                izejaMenu1MouseClicked(evt);
            }
        });
        jMenuBar11.add(izejaMenu1);

        tests2.setJMenuBar(jMenuBar11);

        javax.swing.GroupLayout tests2Layout = new javax.swing.GroupLayout(tests2.getContentPane());
        tests2.getContentPane().setLayout(tests2Layout);
        tests2Layout.setHorizontalGroup(
            tests2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tests2Layout.createSequentialGroup()
                .addGroup(tests2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tests2Layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tests2Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(testVisumsLab1)))
                .addContainerGap(67, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tests2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(testLab3)
                .addGap(138, 138, 138))
        );
        tests2Layout.setVerticalGroup(
            tests2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tests2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testLab3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(testVisumsLab1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        test2jautajums1.setTitle("1 Jautājums");

        testSkaitlisLab5.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testSkaitlisLab5.setForeground(new java.awt.Color(0, 102, 153));
        testSkaitlisLab5.setText("1 no 5");

        jautajumsLab6.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jautajumsLab6.setForeground(new java.awt.Color(0, 102, 153));
        jautajumsLab6.setText("Ko nozīmē saīsinājums \"CPU\"?");

        tālākBut4.setBackground(new java.awt.Color(153, 204, 255));
        tālākBut4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tālākBut4.setForeground(new java.awt.Color(0, 102, 153));
        tālākBut4.setText("Tālāk");
        tālākBut4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tālākBut4ActionPerformed(evt);
            }
        });

        jPanel12.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        atbilde11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde11.setForeground(new java.awt.Color(0, 102, 153));
        atbilde11.setText("Central Power Unit");

        atbilde12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde12.setForeground(new java.awt.Color(0, 102, 153));
        atbilde12.setText("Control Program Unit");

        pAtbilde1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        pAtbilde1.setForeground(new java.awt.Color(0, 102, 153));
        pAtbilde1.setText("Central Processing Unit");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(atbilde11)
                    .addComponent(atbilde12)
                    .addComponent(pAtbilde1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(atbilde11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(atbilde12)
                .addGap(12, 12, 12)
                .addComponent(pAtbilde1)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        izietMenu8.setText("Iziet");
        izietMenu8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                izietMenu8MouseClicked(evt);
            }
        });
        jMenuBar12.add(izietMenu8);

        test2jautajums1.setJMenuBar(jMenuBar12);

        javax.swing.GroupLayout test2jautajums1Layout = new javax.swing.GroupLayout(test2jautajums1.getContentPane());
        test2jautajums1.getContentPane().setLayout(test2jautajums1Layout);
        test2jautajums1Layout.setHorizontalGroup(
            test2jautajums1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, test2jautajums1Layout.createSequentialGroup()
                .addGroup(test2jautajums1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(test2jautajums1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(testSkaitlisLab5))
                    .addGroup(test2jautajums1Layout.createSequentialGroup()
                        .addContainerGap(312, Short.MAX_VALUE)
                        .addComponent(tālākBut4))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, test2jautajums1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(test2jautajums1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(test2jautajums1Layout.createSequentialGroup()
                                .addComponent(jautajumsLab6)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(16, 16, 16))
        );
        test2jautajums1Layout.setVerticalGroup(
            test2jautajums1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(test2jautajums1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testSkaitlisLab5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jautajumsLab6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tālākBut4)
                .addGap(19, 19, 19))
        );

        test2jautajums2.setTitle("2 Jautājums");

        testSkaitlisLab6.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testSkaitlisLab6.setForeground(new java.awt.Color(0, 102, 153));
        testSkaitlisLab6.setText("2 no 5");

        jautajumsLab7.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jautajumsLab7.setForeground(new java.awt.Color(0, 102, 153));
        jautajumsLab7.setText("Kura no šīm ierīcēm ir ievades ierīce?");

        tālākBut5.setBackground(new java.awt.Color(153, 204, 255));
        tālākBut5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tālākBut5.setForeground(new java.awt.Color(0, 102, 153));
        tālākBut5.setText("Tālāk");
        tālākBut5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tālākBut5ActionPerformed(evt);
            }
        });

        jPanel13.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        atbilde13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde13.setForeground(new java.awt.Color(0, 102, 153));
        atbilde13.setText("Printeris");

        Patbilde2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Patbilde2.setForeground(new java.awt.Color(0, 102, 153));
        Patbilde2.setText("Tastatūra");

        atbilde14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde14.setForeground(new java.awt.Color(0, 102, 153));
        atbilde14.setText("Monitors");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(atbilde13)
                    .addComponent(Patbilde2)
                    .addComponent(atbilde14))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(atbilde13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Patbilde2)
                .addGap(12, 12, 12)
                .addComponent(atbilde14)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        atpMenu9.setText("Atpakaļ");
        atpMenu9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                atpMenu9MouseClicked(evt);
            }
        });
        jMenuBar13.add(atpMenu9);

        test2jautajums2.setJMenuBar(jMenuBar13);

        javax.swing.GroupLayout test2jautajums2Layout = new javax.swing.GroupLayout(test2jautajums2.getContentPane());
        test2jautajums2.getContentPane().setLayout(test2jautajums2Layout);
        test2jautajums2Layout.setHorizontalGroup(
            test2jautajums2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, test2jautajums2Layout.createSequentialGroup()
                .addGroup(test2jautajums2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(test2jautajums2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(testSkaitlisLab6))
                    .addGroup(test2jautajums2Layout.createSequentialGroup()
                        .addContainerGap(312, Short.MAX_VALUE)
                        .addComponent(tālākBut5))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, test2jautajums2Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(test2jautajums2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(test2jautajums2Layout.createSequentialGroup()
                                .addComponent(jautajumsLab7)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(16, 16, 16))
        );
        test2jautajums2Layout.setVerticalGroup(
            test2jautajums2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(test2jautajums2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testSkaitlisLab6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jautajumsLab7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tālākBut5)
                .addGap(19, 19, 19))
        );

        test2jautajums3.setTitle("3 Jautājums");

        testSkaitlisLab7.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testSkaitlisLab7.setForeground(new java.awt.Color(0, 102, 153));
        testSkaitlisLab7.setText("3 no 5");

        jautajumsLab8.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jautajumsLab8.setForeground(new java.awt.Color(0, 102, 153));
        jautajumsLab8.setText("Kas ir internets?");

        tālākBut6.setBackground(new java.awt.Color(153, 204, 255));
        tālākBut6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tālākBut6.setForeground(new java.awt.Color(0, 102, 153));
        tālākBut6.setText("Tālāk");
        tālākBut6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tālākBut6ActionPerformed(evt);
            }
        });

        jPanel14.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        atbilde15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde15.setForeground(new java.awt.Color(0, 102, 153));
        atbilde15.setText("Datorprogramma");

        atbilde16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde16.setForeground(new java.awt.Color(0, 102, 153));
        atbilde16.setText("Operātājsistēma");

        pAtbilde3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        pAtbilde3.setForeground(new java.awt.Color(0, 102, 153));
        pAtbilde3.setText("Globāls datortīkls");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(atbilde15)
                    .addComponent(atbilde16)
                    .addComponent(pAtbilde3))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(atbilde15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(atbilde16)
                .addGap(12, 12, 12)
                .addComponent(pAtbilde3)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        atpMenu10.setText("Atpakaļ");
        atpMenu10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                atpMenu10MouseClicked(evt);
            }
        });
        jMenuBar14.add(atpMenu10);

        test2jautajums3.setJMenuBar(jMenuBar14);

        javax.swing.GroupLayout test2jautajums3Layout = new javax.swing.GroupLayout(test2jautajums3.getContentPane());
        test2jautajums3.getContentPane().setLayout(test2jautajums3Layout);
        test2jautajums3Layout.setHorizontalGroup(
            test2jautajums3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, test2jautajums3Layout.createSequentialGroup()
                .addGroup(test2jautajums3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(test2jautajums3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(testSkaitlisLab7))
                    .addGroup(test2jautajums3Layout.createSequentialGroup()
                        .addContainerGap(312, Short.MAX_VALUE)
                        .addComponent(tālākBut6))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, test2jautajums3Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(test2jautajums3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(test2jautajums3Layout.createSequentialGroup()
                                .addComponent(jautajumsLab8)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(16, 16, 16))
        );
        test2jautajums3Layout.setVerticalGroup(
            test2jautajums3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(test2jautajums3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testSkaitlisLab7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jautajumsLab8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tālākBut6)
                .addGap(19, 19, 19))
        );

        test2jautajums4.setTitle("4 Jautājums");

        testSkaitlisLab8.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testSkaitlisLab8.setForeground(new java.awt.Color(0, 102, 153));
        testSkaitlisLab8.setText("4 no 5");

        jautajumsLab9.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jautajumsLab9.setForeground(new java.awt.Color(0, 102, 153));
        jautajumsLab9.setText("Kam galvenokārt izmanto paroli?");

        tālākBut7.setBackground(new java.awt.Color(153, 204, 255));
        tālākBut7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tālākBut7.setForeground(new java.awt.Color(0, 102, 153));
        tālākBut7.setText("Tālāk");
        tālākBut7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tālākBut7ActionPerformed(evt);
            }
        });

        jPanel15.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        pAtbilde6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        pAtbilde6.setForeground(new java.awt.Color(0, 102, 153));
        pAtbilde6.setText("Lietotāja datu aizsardzībai");

        atbilde17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde17.setForeground(new java.awt.Color(0, 102, 153));
        atbilde17.setText("Interneta ātruma palielināšanai");

        atbilde18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde18.setForeground(new java.awt.Color(0, 102, 153));
        atbilde18.setText("Datora izslēgšanai");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pAtbilde6)
                    .addComponent(atbilde17)
                    .addComponent(atbilde18))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pAtbilde6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(atbilde17)
                .addGap(12, 12, 12)
                .addComponent(atbilde18)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        atpMenu11.setText("Atpakaļ");
        atpMenu11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                atpMenu11MouseClicked(evt);
            }
        });
        jMenuBar15.add(atpMenu11);

        test2jautajums4.setJMenuBar(jMenuBar15);

        javax.swing.GroupLayout test2jautajums4Layout = new javax.swing.GroupLayout(test2jautajums4.getContentPane());
        test2jautajums4.getContentPane().setLayout(test2jautajums4Layout);
        test2jautajums4Layout.setHorizontalGroup(
            test2jautajums4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, test2jautajums4Layout.createSequentialGroup()
                .addGroup(test2jautajums4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(test2jautajums4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(testSkaitlisLab8))
                    .addGroup(test2jautajums4Layout.createSequentialGroup()
                        .addContainerGap(312, Short.MAX_VALUE)
                        .addComponent(tālākBut7))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, test2jautajums4Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(test2jautajums4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(test2jautajums4Layout.createSequentialGroup()
                                .addComponent(jautajumsLab9)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(16, 16, 16))
        );
        test2jautajums4Layout.setVerticalGroup(
            test2jautajums4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(test2jautajums4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testSkaitlisLab8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jautajumsLab9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tālākBut7)
                .addGap(19, 19, 19))
        );

        test2jautajums5.setTitle("5 Jautājums");

        testSkaitlisLab9.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testSkaitlisLab9.setForeground(new java.awt.Color(0, 102, 153));
        testSkaitlisLab9.setText("5 no 5");

        jautajumsLab10.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jautajumsLab10.setForeground(new java.awt.Color(0, 102, 153));
        jautajumsLab10.setText("Kura no šīm pārlūkprogrammām pastāv?");

        beigtBut1.setBackground(new java.awt.Color(153, 204, 255));
        beigtBut1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        beigtBut1.setForeground(new java.awt.Color(0, 102, 153));
        beigtBut1.setText("Beigt");
        beigtBut1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beigtBut1ActionPerformed(evt);
            }
        });

        jPanel16.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        atbilde19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde19.setForeground(new java.awt.Color(0, 102, 153));
        atbilde19.setText("Microsoft Word");

        pAtbilde7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        pAtbilde7.setForeground(new java.awt.Color(0, 102, 153));
        pAtbilde7.setText("Google Chrome");

        atbilde20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        atbilde20.setForeground(new java.awt.Color(0, 102, 153));
        atbilde20.setText("Google Drive");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(atbilde19)
                    .addComponent(pAtbilde7)
                    .addComponent(atbilde20))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(atbilde19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pAtbilde7)
                .addGap(12, 12, 12)
                .addComponent(atbilde20)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        izietMenu12.setText("Iziet");
        izietMenu12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                izietMenu12MouseClicked(evt);
            }
        });
        jMenuBar16.add(izietMenu12);

        test2jautajums5.setJMenuBar(jMenuBar16);

        javax.swing.GroupLayout test2jautajums5Layout = new javax.swing.GroupLayout(test2jautajums5.getContentPane());
        test2jautajums5.getContentPane().setLayout(test2jautajums5Layout);
        test2jautajums5Layout.setHorizontalGroup(
            test2jautajums5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, test2jautajums5Layout.createSequentialGroup()
                .addGroup(test2jautajums5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(test2jautajums5Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(testSkaitlisLab9))
                    .addGroup(test2jautajums5Layout.createSequentialGroup()
                        .addContainerGap(312, Short.MAX_VALUE)
                        .addComponent(beigtBut1))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, test2jautajums5Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(test2jautajums5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(test2jautajums5Layout.createSequentialGroup()
                                .addComponent(jautajumsLab10)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(16, 16, 16))
        );
        test2jautajums5Layout.setVerticalGroup(
            test2jautajums5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(test2jautajums5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testSkaitlisLab9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jautajumsLab10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(beigtBut1)
                .addGap(19, 19, 19))
        );

        test2Rezultāti.setTitle("Rezultāti par Tests 2");

        testLab4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        testLab4.setForeground(new java.awt.Color(0, 102, 153));
        testLab4.setText("Rezultāti");

        jPanel17.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        testVisumsLab11.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testVisumsLab11.setForeground(new java.awt.Color(0, 102, 153));
        testVisumsLab11.setText("Tests \"Tehnoloģijas un internets\"");

        testVisumsLab12.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testVisumsLab12.setForeground(new java.awt.Color(0, 102, 153));
        testVisumsLab12.setText("Rezultāts: ");

        testVisumsLab13.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        testVisumsLab13.setForeground(new java.awt.Color(0, 102, 153));
        testVisumsLab13.setText("Datums:");

        jScrollPane7.setViewportView(jTextPane7);

        jScrollPane8.setViewportView(jTextPane8);

        pAtbildesLab5.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        pAtbildesLab5.setForeground(new java.awt.Color(0, 102, 153));
        pAtbildesLab5.setText("Pareizas atbildes:");

        jScrollPane10.setViewportView(jTextPane10);

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(testVisumsLab13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane8))
                    .addComponent(testVisumsLab11)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(testVisumsLab12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(pAtbildesLab5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(testVisumsLab11)
                .addGap(18, 18, 18)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(testVisumsLab12)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pAtbildesLab5)
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(testVisumsLab13)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        izejaBut4.setBackground(new java.awt.Color(153, 204, 255));
        izejaBut4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        izejaBut4.setForeground(new java.awt.Color(0, 102, 153));
        izejaBut4.setText("Atpakaļ");
        izejaBut4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                izejaBut4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout test2RezultātiLayout = new javax.swing.GroupLayout(test2Rezultāti.getContentPane());
        test2Rezultāti.getContentPane().setLayout(test2RezultātiLayout);
        test2RezultātiLayout.setHorizontalGroup(
            test2RezultātiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, test2RezultātiLayout.createSequentialGroup()
                .addGroup(test2RezultātiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, test2RezultātiLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(test2RezultātiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(testLab4)
                            .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(test2RezultātiLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(izejaBut4)))
                .addGap(20, 20, 20))
        );
        test2RezultātiLayout.setVerticalGroup(
            test2RezultātiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(test2RezultātiLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(testLab4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(izejaBut4)
                .addGap(16, 16, 16))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Mini_Testi");

        ielogLab3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        ielogLab3.setForeground(new java.awt.Color(0, 102, 153));
        ielogLab3.setText("Mini Testi");

        jPanel11.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        test1But1.setBackground(new java.awt.Color(153, 204, 255));
        test1But1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        test1But1.setForeground(new java.awt.Color(0, 102, 153));
        test1But1.setText("Tests 1");
        test1But1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                test1But1ActionPerformed(evt);
            }
        });

        test2But.setBackground(new java.awt.Color(153, 204, 255));
        test2But.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        test2But.setForeground(new java.awt.Color(0, 102, 153));
        test2But.setText("Tests 2");
        test2But.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                test2ButActionPerformed(evt);
            }
        });

        izejaBut5.setBackground(new java.awt.Color(153, 204, 255));
        izejaBut5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        izejaBut5.setForeground(new java.awt.Color(0, 102, 153));
        izejaBut5.setText("Izeja");
        izejaBut5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                izejaBut5ActionPerformed(evt);
            }
        });

        rezBut2.setBackground(new java.awt.Color(153, 204, 255));
        rezBut2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        rezBut2.setForeground(new java.awt.Color(0, 102, 153));
        rezBut2.setText("Rezultāti");
        rezBut2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rezBut2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(rezBut2, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                    .addComponent(izejaBut5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(test2But, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(test1But1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(test1But1)
                .addGap(18, 18, 18)
                .addComponent(test2But)
                .addGap(18, 18, 18)
                .addComponent(rezBut2)
                .addGap(18, 18, 18)
                .addComponent(izejaBut5)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(ielogLab3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(ielogLab3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(66, Short.MAX_VALUE))
        );

        setBounds(0, 0, 260, 353);
    }// </editor-fold>//GEN-END:initComponents

    private void tests1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tests1MouseClicked
        
    }//GEN-LAST:event_tests1MouseClicked

    private void izejaButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_izejaButActionPerformed
        tests1.dispose();
    }//GEN-LAST:event_izejaButActionPerformed

    private void saktTestuButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saktTestuButActionPerformed
        tests1.setVisible(false);
        test1jautajums1.setVisible(true);
        test1jautajums1.pack();
        test1jautajums1.setLocationRelativeTo(null);
        test1jautajums1.setModal(true);
    }//GEN-LAST:event_saktTestuButActionPerformed

    private void atpakal2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atpakal2ActionPerformed
        rezultatiJd.dispose();
    }//GEN-LAST:event_atpakal2ActionPerformed

    private void regBut3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regBut3ActionPerformed
        registresanaJd.setVisible(false);
        registerUser();
        
    if (selectedTest == 1) {
        tests1.setVisible(true);
        tests1.pack();
        tests1.setLocationRelativeTo(null);
        tests1.setModal(true);
    } 
    else if (selectedTest == 2) {
        tests2.setVisible(true);
        tests2.pack();
        tests2.setLocationRelativeTo(null);
        tests2.setModal(true); 
    }
        
    }//GEN-LAST:event_regBut3ActionPerformed

    private void ilogButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ilogButActionPerformed
        ielogosanaJd.setVisible(false);
        loginUser();

    if (selectedTest == 1) {
        tests1.setVisible(true);
        tests1.pack();
        tests1.setLocationRelativeTo(null);
        tests1.setModal(true);
    } 
    else if (selectedTest == 2) {
        tests2.setVisible(true);
        tests2.pack();
        tests2.setLocationRelativeTo(null);
        tests2.setModal(true);
    }
        
    }//GEN-LAST:event_ilogButActionPerformed

    private void regBut14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regBut14ActionPerformed
        ielogosanaJd.setVisible(false);
        registresanaJd.setVisible(true);
        registresanaJd.pack();
        registresanaJd.setLocationRelativeTo(null);
        registresanaJd.setModal(true);
    }//GEN-LAST:event_regBut14ActionPerformed

    private void tālākButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tālākButActionPerformed
        test1jautajums1.setVisible(false);
        test1jautajums2.setVisible(true);
        test1jautajums2.pack();
        test1jautajums2.setLocationRelativeTo(null);
        test1jautajums2.setModal(true);
       
        int selected = -1;
        if (atbilde1.isSelected()) selected = 0;
        if (atbilde2.isSelected()) selected = 1;
        if (pAtbilde.isSelected()) selected = 2;
        testLogic1.checkAnswer(selected);
        testLogic1.nextQuestion();
    }//GEN-LAST:event_tālākButActionPerformed

    private void tālākBut1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tālākBut1ActionPerformed
        test1jautajums2.setVisible(false); 
        test1jautajums3.setVisible(true);
        test1jautajums3.pack();
        test1jautajums3.setLocationRelativeTo(null);
        test1jautajums3.setModal(true);
        
        int selected = -1;
        if (atbilde3.isSelected()) selected = 0;
        if (pAtbilde1.isSelected()) selected = 1;
        if (atbilde4.isSelected()) selected = 2;
        testLogic1.checkAnswer(selected);
        testLogic1.nextQuestion();
    }//GEN-LAST:event_tālākBut1ActionPerformed

    private void tālākBut2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tālākBut2ActionPerformed
        test1jautajums3.setVisible(false); 
        test1jautajums4.setVisible(true);
        test1jautajums4.pack();
        test1jautajums4.setLocationRelativeTo(null);
        test1jautajums4.setModal(true);
        
        int selected = -1;
        if (atbilde5.isSelected()) selected = 0;
        if (atbilde6.isSelected()) selected = 1;
        if (pAtbilde2.isSelected()) selected = 2;
        testLogic1.checkAnswer(selected);
        testLogic1.nextQuestion();
    }//GEN-LAST:event_tālākBut2ActionPerformed

    private void tālākBut3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tālākBut3ActionPerformed
        test1jautajums4.setVisible(false); 
        test1jautajums5.setVisible(true);
        test1jautajums5.pack();
        test1jautajums5.setLocationRelativeTo(null);
        test1jautajums5.setModal(true);
        
        int selected = -1;
        if (pAtbilde4.isSelected()) selected = 0;
        if (atbilde7.isSelected()) selected = 1;
        if (atbilde8.isSelected()) selected = 2;
        testLogic1.checkAnswer(selected);
        testLogic1.nextQuestion();
    }//GEN-LAST:event_tālākBut3ActionPerformed

    private void beigtButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beigtButActionPerformed
        test1jautajums5.setVisible(false); 
        test1Rezultāti.setVisible(true);
        test1Rezultāti.pack();
        test1Rezultāti.setLocationRelativeTo(null);
        test1Rezultāti.setModal(true);
        
        int selected = -1;
        if (atbilde9.isSelected()) selected = 0;
        if (pAtbilde5.isSelected()) selected = 1;
        if (atbilde10.isSelected()) selected = 2;
        testLogic1.checkAnswer(selected);
        
        int percent = testLogic1.getPercentage();
        java.sql.Date date = new java.sql.Date(System.currentTimeMillis());

        String atbildes = testLogic1.getCorrectAnswers() + " no " + testLogic1.getTotalQuestions();

        jTextPane11.setText(atbildes);
        jTextPane1.setText(percent + "%");
        jTextPane9.setText(date.toString());
        
        jTextPane3.setText(percent + "%");
        jTextPane4.setText(date.toString());

        saveResult(percent, date, atbildes);
        
    }//GEN-LAST:event_beigtButActionPerformed

    private void atpakalBut1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atpakalBut1ActionPerformed
        test1Rezultāti.setVisible(false);
        tests1.setVisible(true);
        tests1.pack();
        tests1.setLocationRelativeTo(null);
        tests1.setModal(true);
    }//GEN-LAST:event_atpakalBut1ActionPerformed

    private void test1But1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_test1But1ActionPerformed
        selectedTest = 1;
        ielogosanaJd.setVisible(false);
        ielogosanaJd.setVisible(true);
        ielogosanaJd.pack();
        ielogosanaJd.setLocationRelativeTo(null);
        ielogosanaJd.setModal(true);
    }//GEN-LAST:event_test1But1ActionPerformed

    private void test2ButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_test2ButActionPerformed
        selectedTest = 2;
        ielogosanaJd.setVisible(false);
        ielogosanaJd.setVisible(true);
        ielogosanaJd.pack();
        ielogosanaJd.setLocationRelativeTo(null);
        ielogosanaJd.setModal(true);
    }//GEN-LAST:event_test2ButActionPerformed

    private void saktTestuBut1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saktTestuBut1ActionPerformed
        tests2.setVisible(false);
        test2jautajums1.setVisible(true);
        test2jautajums1.pack();
        test2jautajums1.setLocationRelativeTo(null);
        test2jautajums1.setModal(true);
    }//GEN-LAST:event_saktTestuBut1ActionPerformed

    private void tālākBut4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tālākBut4ActionPerformed
        test2jautajums1.setVisible(false);
        test2jautajums2.setVisible(true);
        test2jautajums2.pack();
        test2jautajums2.setLocationRelativeTo(null);
        test2jautajums2.setModal(true);
        
        int selected = -1;
        if (atbilde11.isSelected()) selected = 0;
        if (atbilde12.isSelected()) selected = 1;
        if (pAtbilde1.isSelected()) selected = 2;
        testLogic2.checkAnswer(selected);
        testLogic2.nextQuestion();
    }//GEN-LAST:event_tālākBut4ActionPerformed

    private void tālākBut5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tālākBut5ActionPerformed
        test2jautajums2.setVisible(false);
        test2jautajums3.setVisible(true);
        test2jautajums3.pack();
        test2jautajums3.setLocationRelativeTo(null);
        test2jautajums3.setModal(true);
        
        int selected = -1;
        if (atbilde13.isSelected()) selected = 0;
        if (pAtbilde2.isSelected()) selected = 1;
        if (atbilde14.isSelected()) selected = 2;
        testLogic2.checkAnswer(selected);
        testLogic2.nextQuestion();
    }//GEN-LAST:event_tālākBut5ActionPerformed

    private void tālākBut6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tālākBut6ActionPerformed
        test2jautajums3.setVisible(false);
        test2jautajums4.setVisible(true);
        test2jautajums4.pack();
        test2jautajums4.setLocationRelativeTo(null);
        test2jautajums4.setModal(true);
        
        int selected = -1;
        if (atbilde15.isSelected()) selected = 0;
        if (atbilde16.isSelected()) selected = 1;
        if (pAtbilde3.isSelected()) selected = 2;
        testLogic2.checkAnswer(selected);
        testLogic2.nextQuestion();
    }//GEN-LAST:event_tālākBut6ActionPerformed

    private void tālākBut7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tālākBut7ActionPerformed
        test2jautajums4.setVisible(false);
        test2jautajums5.setVisible(true);
        test2jautajums5.pack();
        test2jautajums5.setLocationRelativeTo(null);
        test2jautajums5.setModal(true);
        
        int selected = -1;
        if (pAtbilde6.isSelected()) selected = 0;
        if (atbilde17.isSelected()) selected = 1;
        if (atbilde18.isSelected()) selected = 2;
        testLogic2.checkAnswer(selected);
        testLogic2.nextQuestion();
    }//GEN-LAST:event_tālākBut7ActionPerformed

    private void beigtBut1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beigtBut1ActionPerformed
        test2jautajums5.setVisible(false);
        test2Rezultāti.setVisible(true);
        test2Rezultāti.pack();
        test2Rezultāti.setLocationRelativeTo(null);
        test2Rezultāti.setModal(true);
        
        int selected = -1;
        if (atbilde19.isSelected()) selected = 0;
        if (pAtbilde7.isSelected()) selected = 1;
        if (atbilde20.isSelected()) selected = 2;
        testLogic2.checkAnswer(selected);
        testLogic2.nextQuestion();
        test2jautajums5.setVisible(false);
        testLogic2.checkAnswer(selected);
    
        
        int percent = testLogic2.getPercentage();
        java.sql.Date date = new java.sql.Date(System.currentTimeMillis());

        String atbildes = testLogic2.getCorrectAnswers() + " no " + testLogic2.getTotalQuestions();

        jTextPane7.setText(atbildes);
        jTextPane10.setText(percent + "%");
        jTextPane8.setText(date.toString());
        
        jTextPane5.setText(percent + "%");
        jTextPane6.setText(date.toString());

        saveResult(percent, date, atbildes);
        
    }//GEN-LAST:event_beigtBut1ActionPerformed

    private void izejaBut4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_izejaBut4ActionPerformed
        test2Rezultāti.setVisible(false);
        tests2.setVisible(true);
        tests2.pack();
        tests2.setLocationRelativeTo(null);
        tests2.setModal(true);
    }//GEN-LAST:event_izejaBut4ActionPerformed

    private void izejaBut3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_izejaBut3ActionPerformed
        tests2.dispose();
    }//GEN-LAST:event_izejaBut3ActionPerformed

    private void rezBut2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rezBut2ActionPerformed
        rezultatiJd.setVisible(true);
        rezultatiJd.pack();
        rezultatiJd.setLocationRelativeTo(null);
        rezultatiJd.setModal(true);
    }//GEN-LAST:event_rezBut2ActionPerformed

    private void izejaBut5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_izejaBut5ActionPerformed
        this.dispose();
    }//GEN-LAST:event_izejaBut5ActionPerformed

    private void izietMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_izietMenuMouseClicked
        registresanaJd.dispose();
    }//GEN-LAST:event_izietMenuMouseClicked

    private void izejaMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_izejaMenuMouseClicked
        tests1.dispose();
    }//GEN-LAST:event_izejaMenuMouseClicked

    private void izietMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_izietMenu1MouseClicked
        test1jautajums1.setVisible(false);
        tests1.setVisible(true);
        tests1.pack();
        tests1.setLocationRelativeTo(null);
        tests1.setModal(true);
    }//GEN-LAST:event_izietMenu1MouseClicked

    private void atpMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_atpMenu2MouseClicked
        test1jautajums2.setVisible(false);
        test1jautajums1.setVisible(true);
        test1jautajums1.pack();
        test1jautajums1.setLocationRelativeTo(null);
        test1jautajums1.setModal(true);
    }//GEN-LAST:event_atpMenu2MouseClicked

    private void atpMenu3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_atpMenu3MouseClicked
        test1jautajums3.setVisible(false);
        test1jautajums2.setVisible(true);
        test1jautajums2.pack();
        test1jautajums2.setLocationRelativeTo(null);
        test1jautajums2.setModal(true);
        
    }//GEN-LAST:event_atpMenu3MouseClicked

    private void atpMenu4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_atpMenu4MouseClicked
        test1jautajums4.setVisible(false);
        test1jautajums3.setVisible(true);
        test1jautajums3.pack();
        test1jautajums3.setLocationRelativeTo(null);
        test1jautajums3.setModal(true);
    }//GEN-LAST:event_atpMenu4MouseClicked

    private void izietMenu5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_izietMenu5MouseClicked
        test1jautajums5.setVisible(false);
        tests1.setVisible(true);
        tests1.pack();
        tests1.setLocationRelativeTo(null);
        tests1.setModal(true);
    }//GEN-LAST:event_izietMenu5MouseClicked

    private void atpMenu6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_atpMenu6MouseClicked
        ielogosanaJd.dispose();
    }//GEN-LAST:event_atpMenu6MouseClicked

    private void izejaMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_izejaMenu1MouseClicked
        tests2.dispose();
    }//GEN-LAST:event_izejaMenu1MouseClicked

    private void izietMenu8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_izietMenu8MouseClicked
        test2jautajums1.setVisible(false);
        tests2.setVisible(true);
        tests2.pack();
        tests2.setLocationRelativeTo(null);
        tests2.setModal(true);
    }//GEN-LAST:event_izietMenu8MouseClicked

    private void atpMenu9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_atpMenu9MouseClicked
        test2jautajums2.setVisible(false);
        test2jautajums1.setVisible(true);
        test2jautajums1.pack();
        test2jautajums1.setLocationRelativeTo(null);
        test2jautajums1.setModal(true);
    }//GEN-LAST:event_atpMenu9MouseClicked

    private void atpMenu10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_atpMenu10MouseClicked
        test2jautajums3.setVisible(false);
        test2jautajums2.setVisible(true);
        test2jautajums2.pack();
        test2jautajums2.setLocationRelativeTo(null);
        test2jautajums2.setModal(true);
    }//GEN-LAST:event_atpMenu10MouseClicked

    private void atpMenu11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_atpMenu11MouseClicked
        test2jautajums4.setVisible(false);
        test2jautajums3.setVisible(true);
        test2jautajums3.pack();
        test2jautajums3.setLocationRelativeTo(null);
        test2jautajums3.setModal(true);
    }//GEN-LAST:event_atpMenu11MouseClicked

    private void izietMenu12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_izietMenu12MouseClicked
        test2jautajums5.setVisible(false);
        tests2.setVisible(true);
        tests2.pack();
        tests2.setLocationRelativeTo(null);
        tests2.setModal(true);
    }//GEN-LAST:event_izietMenu12MouseClicked

    private void vardsText1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vardsText1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_vardsText1ActionPerformed

    private void pAtbildeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pAtbildeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pAtbildeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PD1_PA_Balalajeva_GUI().setVisible(true);
            }
        });
        
        Connection conn = DBConnection.getConnection();
        if (conn != null) {
            System.out.println("Savienojums ar datubazi veiksmigs!");
        } else {
            System.out.println("Savienojuma ir kluda!");
        }
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox Patbilde1;
    private javax.swing.JCheckBox Patbilde2;
    private javax.swing.JCheckBox atbilde1;
    private javax.swing.JCheckBox atbilde10;
    private javax.swing.JCheckBox atbilde11;
    private javax.swing.JCheckBox atbilde12;
    private javax.swing.JCheckBox atbilde13;
    private javax.swing.JCheckBox atbilde14;
    private javax.swing.JCheckBox atbilde15;
    private javax.swing.JCheckBox atbilde16;
    private javax.swing.JCheckBox atbilde17;
    private javax.swing.JCheckBox atbilde18;
    private javax.swing.JCheckBox atbilde19;
    private javax.swing.JCheckBox atbilde2;
    private javax.swing.JCheckBox atbilde20;
    private javax.swing.JCheckBox atbilde3;
    private javax.swing.JCheckBox atbilde4;
    private javax.swing.JCheckBox atbilde5;
    private javax.swing.JCheckBox atbilde6;
    private javax.swing.JCheckBox atbilde7;
    private javax.swing.JCheckBox atbilde8;
    private javax.swing.JCheckBox atbilde9;
    private javax.swing.JMenu atpMenu10;
    private javax.swing.JMenu atpMenu11;
    private javax.swing.JMenu atpMenu2;
    private javax.swing.JMenu atpMenu3;
    private javax.swing.JMenu atpMenu4;
    private javax.swing.JMenu atpMenu6;
    private javax.swing.JMenu atpMenu9;
    private javax.swing.JButton atpakal2;
    private javax.swing.JButton atpakalBut1;
    private javax.swing.JButton beigtBut;
    private javax.swing.JButton beigtBut1;
    private javax.swing.JLabel ielogLab3;
    private javax.swing.JLabel ielogLab4;
    private javax.swing.JDialog ielogosanaJd;
    private javax.swing.JButton ilogBut;
    private javax.swing.JButton izejaBut;
    private javax.swing.JButton izejaBut3;
    private javax.swing.JButton izejaBut4;
    private javax.swing.JButton izejaBut5;
    private javax.swing.JMenu izejaMenu;
    private javax.swing.JMenu izejaMenu1;
    private javax.swing.JMenu izietMenu;
    private javax.swing.JMenu izietMenu1;
    private javax.swing.JMenu izietMenu12;
    private javax.swing.JMenu izietMenu5;
    private javax.swing.JMenu izietMenu8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar11;
    private javax.swing.JMenuBar jMenuBar12;
    private javax.swing.JMenuBar jMenuBar13;
    private javax.swing.JMenuBar jMenuBar14;
    private javax.swing.JMenuBar jMenuBar15;
    private javax.swing.JMenuBar jMenuBar16;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuBar jMenuBar4;
    private javax.swing.JMenuBar jMenuBar5;
    private javax.swing.JMenuBar jMenuBar6;
    private javax.swing.JMenuBar jMenuBar7;
    private javax.swing.JMenuBar jMenuBar8;
    private javax.swing.JMenuBar jMenuBar9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JTextPane jTextPane10;
    private javax.swing.JTextPane jTextPane11;
    private javax.swing.JTextPane jTextPane3;
    private javax.swing.JTextPane jTextPane4;
    private javax.swing.JTextPane jTextPane5;
    private javax.swing.JTextPane jTextPane6;
    private javax.swing.JTextPane jTextPane7;
    private javax.swing.JTextPane jTextPane8;
    private javax.swing.JTextPane jTextPane9;
    private javax.swing.JLabel jautajumsLab1;
    private javax.swing.JLabel jautajumsLab10;
    private javax.swing.JLabel jautajumsLab2;
    private javax.swing.JLabel jautajumsLab3;
    private javax.swing.JLabel jautajumsLab4;
    private javax.swing.JLabel jautajumsLab5;
    private javax.swing.JLabel jautajumsLab6;
    private javax.swing.JLabel jautajumsLab7;
    private javax.swing.JLabel jautajumsLab8;
    private javax.swing.JLabel jautajumsLab9;
    private javax.swing.JLabel letvardsLab2;
    private javax.swing.JLabel letvardsLab4;
    private javax.swing.JTextField lietvardsText2;
    private javax.swing.JTextField lietvardsText4;
    private javax.swing.JCheckBox pAtbilde;
    private javax.swing.JCheckBox pAtbilde1;
    private javax.swing.JCheckBox pAtbilde2;
    private javax.swing.JCheckBox pAtbilde3;
    private javax.swing.JCheckBox pAtbilde4;
    private javax.swing.JCheckBox pAtbilde5;
    private javax.swing.JCheckBox pAtbilde6;
    private javax.swing.JCheckBox pAtbilde7;
    private javax.swing.JLabel pAtbildesLab4;
    private javax.swing.JLabel pAtbildesLab5;
    private javax.swing.JLabel paroleAtkLab1;
    private javax.swing.JTextField paroleAtkText1;
    private javax.swing.JLabel paroleLab2;
    private javax.swing.JLabel paroleLab4;
    private javax.swing.JTextField paroleText1;
    private javax.swing.JTextField paroleText4;
    private javax.swing.JButton regBut14;
    private javax.swing.JButton regBut3;
    private javax.swing.JLabel regLab1;
    private javax.swing.JDialog registresanaJd;
    private javax.swing.JButton rezBut2;
    private javax.swing.JLabel rezultLab3;
    private javax.swing.JDialog rezultatiJd;
    private javax.swing.JButton saktTestuBut;
    private javax.swing.JButton saktTestuBut1;
    private javax.swing.JButton test1But1;
    private javax.swing.JDialog test1Rezultāti;
    private javax.swing.JDialog test1jautajums1;
    private javax.swing.JDialog test1jautajums2;
    private javax.swing.JDialog test1jautajums3;
    private javax.swing.JDialog test1jautajums4;
    private javax.swing.JDialog test1jautajums5;
    private javax.swing.JButton test2But;
    private javax.swing.JDialog test2Rezultāti;
    private javax.swing.JDialog test2jautajums1;
    private javax.swing.JDialog test2jautajums2;
    private javax.swing.JDialog test2jautajums3;
    private javax.swing.JDialog test2jautajums4;
    private javax.swing.JDialog test2jautajums5;
    private javax.swing.JLabel testLab;
    private javax.swing.JLabel testLab1;
    private javax.swing.JLabel testLab2;
    private javax.swing.JLabel testLab3;
    private javax.swing.JLabel testLab4;
    private javax.swing.JLabel testSkaitlisLab;
    private javax.swing.JLabel testSkaitlisLab1;
    private javax.swing.JLabel testSkaitlisLab2;
    private javax.swing.JLabel testSkaitlisLab3;
    private javax.swing.JLabel testSkaitlisLab4;
    private javax.swing.JLabel testSkaitlisLab5;
    private javax.swing.JLabel testSkaitlisLab6;
    private javax.swing.JLabel testSkaitlisLab7;
    private javax.swing.JLabel testSkaitlisLab8;
    private javax.swing.JLabel testSkaitlisLab9;
    private javax.swing.JLabel testVisumsLab;
    private javax.swing.JLabel testVisumsLab1;
    private javax.swing.JLabel testVisumsLab10;
    private javax.swing.JLabel testVisumsLab11;
    private javax.swing.JLabel testVisumsLab12;
    private javax.swing.JLabel testVisumsLab13;
    private javax.swing.JLabel testVisumsLab14;
    private javax.swing.JLabel testVisumsLab2;
    private javax.swing.JLabel testVisumsLab5;
    private javax.swing.JLabel testVisumsLab6;
    private javax.swing.JLabel testVisumsLab7;
    private javax.swing.JLabel testVisumsLab8;
    private javax.swing.JLabel testVisumsLab9;
    private javax.swing.JDialog tests1;
    private javax.swing.JDialog tests2;
    private javax.swing.JButton tālākBut;
    private javax.swing.JButton tālākBut1;
    private javax.swing.JButton tālākBut2;
    private javax.swing.JButton tālākBut3;
    private javax.swing.JButton tālākBut4;
    private javax.swing.JButton tālākBut5;
    private javax.swing.JButton tālākBut6;
    private javax.swing.JButton tālākBut7;
    private javax.swing.JLabel uzvardsLab1;
    private javax.swing.JTextField uzvardsText1;
    private javax.swing.JLabel vardsLab1;
    private javax.swing.JTextField vardsText1;
    // End of variables declaration//GEN-END:variables
}
